<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>OOPS</title>
</head>
<body>
<div class="jumbotron">
<h1>Oops! Looks like you are a restaurant, You can't Order stuff!</h1>
</div>
</body>
</html>